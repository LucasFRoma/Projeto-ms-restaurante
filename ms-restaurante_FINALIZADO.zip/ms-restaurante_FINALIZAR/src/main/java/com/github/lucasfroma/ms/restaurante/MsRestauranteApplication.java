package com.github.lucasfroma.ms.restaurante;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsRestauranteApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsRestauranteApplication.class, args);
	}

}
